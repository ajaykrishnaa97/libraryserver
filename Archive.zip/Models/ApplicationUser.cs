using Microsoft.AspNetCore.Identity;

namespace Library.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Any extra fields if needed.
    }
}
